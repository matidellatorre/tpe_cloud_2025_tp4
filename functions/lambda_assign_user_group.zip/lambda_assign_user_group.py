import json
import os
import boto3

# Initialize Cognito client
cognito_client = boto3.client('cognito-idp', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

USER_POOL_ID = os.environ.get('COGNITO_USER_POOL_ID')


def handler(event, context):
    """
    Assign a user to a Cognito group after signup.
    
    Expected event body:
    {
        "username": "user@example.com",
        "group": "client" or "company"
    }
    """
    try:
        body = json.loads(event.get("body", "{}"))
        username = body.get("username")
        group = body.get("group")
        
        if not username or not group:
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": "Missing required fields: username, group"
                })
            }
        
        if group not in ["client", "company"]:
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": "Invalid group. Must be 'client' or 'company'"
                })
            }
        
        if not USER_POOL_ID:
            return {
                "statusCode": 500,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": "COGNITO_USER_POOL_ID not configured"
                })
            }
        
        # Add user to the specified group
        cognito_client.admin_add_user_to_group(
            UserPoolId=USER_POOL_ID,
            Username=username,
            GroupName=group
        )
        
        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "message": f"User {username} successfully added to {group} group"
            })
        }
        
    except cognito_client.exceptions.UserNotFoundException:
        return {
            "statusCode": 404,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": "User not found"
            })
        }
    except cognito_client.exceptions.ResourceNotFoundException:
        return {
            "statusCode": 404,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": "Group not found"
            })
        }
    except Exception as e:
        print(f"Error assigning user to group: {e}")
        return {
            "statusCode": 500,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({
                "error": "An error occurred",
                "details": str(e)
            })
        }


"""
Utility functions for authentication and authorization
Extracts user information and groups from Cognito JWT token
"""
import json
import base64
import os


def get_user_groups_from_event(event):
    """
    Extract user groups from the Cognito JWT token in the API Gateway event.
    
    The groups are included in the requestContext.authorizer.claims.cognito:groups
    when the user is authenticated via Cognito JWT authorizer.
    
    Note: The claim name in API Gateway might be 'cognito:groups' or 'cognito_groups'
    depending on how the authorizer processes the JWT token.
    
    Args:
        event: Lambda event from API Gateway
        
    Returns:
        list: List of group names the user belongs to, or empty list if none
    """
    try:
        # API Gateway includes the JWT claims in the request context
        request_context = event.get("requestContext", {})
        authorizer = request_context.get("authorizer", {})
        claims = authorizer.get("claims", {})
        
        # Try different possible claim names for groups
        # Cognito groups can be in 'cognito:groups' or 'cognito_groups' (colon replaced with underscore)
        groups = claims.get("cognito:groups") or claims.get("cognito_groups") or ""
        
        if groups:
            # Groups can be a string (single group) or comma-separated string
            if isinstance(groups, str):
                # Split by comma and strip whitespace
                return [g.strip() for g in groups.split(",") if g.strip()]
            elif isinstance(groups, list):
                return groups
        
        # Debug: print all claims to help troubleshoot
        print(f"Available claims: {list(claims.keys())}")
        
        return []
    except Exception as e:
        print(f"Error extracting user groups: {e}")
        import traceback
        traceback.print_exc()
        return []


def get_user_email_from_event(event):
    """
    Extract user email from the Cognito JWT token in the API Gateway event.
    
    Args:
        event: Lambda event from API Gateway
        
    Returns:
        str: User email or None if not found
    """
    try:
        request_context = event.get("requestContext", {})
        authorizer = request_context.get("authorizer", {})
        claims = authorizer.get("claims", {})
        
        # Email is in the 'email' claim
        return claims.get("email") or claims.get("cognito:username")
    except Exception as e:
        print(f"Error extracting user email: {e}")
        return None


def get_user_sub_from_event(event):
    """
    Extract user sub (Cognito user ID) from the JWT token.
    
    Args:
        event: Lambda event from API Gateway
        
    Returns:
        str: User sub or None if not found
    """
    try:
        request_context = event.get("requestContext", {})
        authorizer = request_context.get("authorizer", {})
        claims = authorizer.get("claims", {})
        
        return claims.get("sub")
    except Exception as e:
        print(f"Error extracting user sub: {e}")
        return None


def check_user_has_role(event, required_role):
    """
    Check if the user has the required role (group).
    
    Args:
        event: Lambda event from API Gateway
        required_role: Required role name ('client' or 'company')
        
    Returns:
        bool: True if user has the required role, False otherwise
    """
    user_groups = get_user_groups_from_event(event)
    return required_role in user_groups


def require_role(required_role):
    """
    Decorator function to require a specific role for a Lambda handler.
    
    Usage:
        @require_role('company')
        def handler(event, context):
            # Only users with 'company' role can access this
            ...
    """
    def decorator(handler_func):
        def wrapper(event, context):
            if not check_user_has_role(event, required_role):
                return {
                    "statusCode": 403,
                    "headers": {"Access-Control-Allow-Origin": "*"},
                    "body": json.dumps({
                        "error": "Forbidden",
                        "message": f"This operation requires '{required_role}' role"
                    })
                }
            return handler_func(event, context)
        return wrapper
    return decorator

